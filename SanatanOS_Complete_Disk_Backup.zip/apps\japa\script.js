document.addEventListener('DOMContentLoaded', () => {
    // === DOM Elements ===
    const canvas = document.getElementById('japa-canvas');
    const beadCountEl = document.getElementById('bead-count');
    const malaCountEl = document.getElementById('mala-count');
    const levelText = document.getElementById('level-text');
    const levelBadge = document.getElementById('level-badge');
    const divineFlash = document.getElementById('divine-flash');
    const malaContainer = document.getElementById('mala-container');
    const malaComplete = document.getElementById('mala-complete');
    const completeCount = document.getElementById('complete-count');

    // Name Selector
    const nameSelectorBtn = document.getElementById('name-selector-btn');
    const selectedNameEl = document.getElementById('selected-name');
    const deityNameText = document.getElementById('deity-name-text'); // Centered display
    const nameModal = document.getElementById('name-modal');
    const nameOptions = document.querySelectorAll('.name-option');

    // Settings
    const settingsBtn = document.getElementById('settings-btn');
    const settingsModal = document.getElementById('settings-modal');
    const accordionHeaders = document.querySelectorAll('.accordion-header');

    // Language
    const langHi = document.getElementById('lang-hi');
    const langEn = document.getElementById('lang-en');

    // Sound
    const soundOnBtn = document.getElementById('sound-on-btn');
    const soundOffBtn = document.getElementById('sound-off-btn');
    const soundOptions = document.querySelectorAll('.sound-option');

    // Stats - Enhanced
    const totalNaamsEl = document.getElementById('total-naams');
    const totalMalasEl = document.getElementById('total-malas');
    const bestDayEl = document.getElementById('best-day');
    const streakCountEl = document.getElementById('streak-count');
    const chartContainer = document.getElementById('chart-container');

    // Reset
    const resetData = document.getElementById('reset-data');

    // Reminder
    const reminderToggleBtn = document.getElementById('reminder-toggle-btn');
    const reminderTimeSection = document.getElementById('reminder-time-section');
    const reminderTimeInput = document.getElementById('reminder-time');
    const reminderStatus = document.getElementById('reminder-status');

    // Close buttons
    document.querySelectorAll('.close-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const modalId = btn.dataset.close;
            document.getElementById(modalId).classList.remove('active');
        });
    });

    // Audio
    const sounds = {
        bell: document.getElementById('bell-sound'),
        conch: document.getElementById('conch-sound'),
        bowl: document.getElementById('bowl-sound'),
        chime: document.getElementById('chime-sound')
    };

    // === Deity Data (7 deities = 7 themes) ===
    const DEITIES = {
        radha: { text_hi: 'श्री राधा', text_en: 'Shree Radha', color: '#ff69b4' },
        krishna: { text_hi: 'श्री कृष्ण', text_en: 'Shree Krishna', color: '#ffd700' },
        ram: { text_hi: 'श्री राम', text_en: 'Shree Ram', color: '#ff9800' },
        shiva: { text_hi: 'ॐ नमः शिवाय', text_en: 'Om Namah Shivaya', color: '#e0e0e0' },
        hanuman: { text_hi: 'ॐ हनुमते नमः', text_en: 'Om Hanumate Namah', color: '#ff5722' },
        ganesha: { text_hi: 'ॐ गं गणपतये नमः', text_en: 'Om Gan Ganapataye Namah', color: '#ffeb3b' },
        durga: { text_hi: 'जय माता दी', text_en: 'Jai Mata Di', color: '#e91e63' }
    };

    // === Levels ===
    const LEVELS = [
        { name: 'Aarambh', icon: '🙏', min: 0 },
        { name: 'Sadhak', icon: '🙇', min: 108 },
        { name: 'Bhakta', icon: '📿', min: 1008 },
        { name: 'Rakshak', icon: '🛡️', min: 10008 },
        { name: 'Siddha', icon: '✨', min: 100008 }
    ];

    // === Constants ===
    const TOTAL_BEADS = 108;
    const BEAD_COUNT = 54;
    const GRID_COLS = 4;
    const GRID_ROWS = 5;
    const TOTAL_SLOTS = GRID_COLS * GRID_ROWS;

    // === State ===
    let state = {
        currentDeity: 'radha',
        language: 'hi',
        beadCount: 0,
        malaCount: 0,
        totalLifetimeCount: 0,
        currentStreak: 0,
        dailyStats: {},
        lastActiveDate: null,
        isMuted: false,
        soundType: 'bell',
        reminderEnabled: false,
        reminderTime: '06:00'
    };

    let availableSlots = [];
    let occupiedSlots = {};
    let malaRotation = 0;
    let lastTapTime = 0;

    // === Initialize ===
    loadState();
    initGridSlots();
    createMalaBeads();
    updateDisplay();
    updateUI();
    updateLevelBadge();
    checkStreak();
    applyTheme(state.currentDeity); // Theme = Deity

    // === Event Listeners ===
    // Tap anywhere on canvas
    canvas.addEventListener('pointerdown', handleTap, { passive: false });

    // Also listen for taps on mala section (below counter)
    const malaSection = document.querySelector('.mala-section');
    if (malaSection) {
        malaSection.addEventListener('pointerdown', (e) => {
            // Don't count if tapping on counter display
            if (!e.target.closest('.counter-display')) {
                handleTap(e);
            }
        }, { passive: false });
    }

    // Name selector
    nameSelectorBtn.addEventListener('click', () => nameModal.classList.add('active'));
    nameModal.addEventListener('click', (e) => {
        if (e.target === nameModal) nameModal.classList.remove('active');
    });

    nameOptions.forEach(option => {
        option.addEventListener('click', () => {
            const deity = option.dataset.deity;
            state.currentDeity = deity;
            applyTheme(deity); // Auto-switch theme
            updateSelectedName();
            updateUI();
            saveState();
            nameModal.classList.remove('active');
        });
    });

    // Settings
    settingsBtn.addEventListener('click', () => {
        updateStats();
        renderChart();
        settingsModal.classList.add('active');
    });
    settingsModal.addEventListener('click', (e) => {
        if (e.target === settingsModal) settingsModal.classList.remove('active');
    });

    // Accordion
    accordionHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const section = header.dataset.section;
            const content = document.getElementById(`${section}-content`);
            const isOpen = !content.classList.contains('collapsed');

            document.querySelectorAll('.accordion-content').forEach(c => c.classList.add('collapsed'));
            document.querySelectorAll('.accordion-header').forEach(h => h.classList.remove('open'));

            if (!isOpen) {
                content.classList.remove('collapsed');
                header.classList.add('open');
            }
        });
    });

    // Language
    langHi.addEventListener('click', () => setLanguage('hi'));
    langEn.addEventListener('click', () => setLanguage('en'));

    // Sound
    soundOnBtn.addEventListener('click', () => setSound(false));
    soundOffBtn.addEventListener('click', () => setSound(true));
    soundOptions.forEach(opt => {
        opt.addEventListener('click', () => {
            state.soundType = opt.dataset.sound;
            updateSoundUI();
            saveState();
        });
    });

    // Reset
    resetData.addEventListener('click', resetAllData);

    // Reminder
    initReminder();
    reminderToggleBtn.addEventListener('click', toggleReminder);
    reminderTimeInput.addEventListener('change', updateReminderTime);

    // === Grid System ===
    function initGridSlots() {
        availableSlots = [];
        for (let i = 0; i < TOTAL_SLOTS; i++) availableSlots.push(i);
        shuffleArray(availableSlots);
    }

    function shuffleArray(arr) {
        for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]];
        }
    }

    function getSlotPosition(slotId) {
        const row = Math.floor(slotId / GRID_COLS);
        const col = slotId % GRID_COLS;
        const cellWidth = 100 / GRID_COLS;
        const cellHeight = 100 / GRID_ROWS;

        // Add padding to keep text inside screen (5% from edges)
        const paddingX = 8;
        const paddingY = 5;
        const offsetX = paddingX + (Math.random() * 0.3 + 0.2) * (cellWidth - paddingX * 2);
        const offsetY = paddingY + (Math.random() * 0.3 + 0.2) * (cellHeight - paddingY * 2);

        const left = Math.min(Math.max(col * cellWidth + offsetX, 5), 85); // Clamp 5-85%
        const top = Math.min(Math.max(row * cellHeight + offsetY, 3), 90); // Clamp 3-90%

        return { left: `${left}%`, top: `${top}%` };
    }

    // === Core Tap Handler ===
    function handleTap(e) {
        e.preventDefault();

        const now = Date.now();
        if (now - lastTapTime < 50) return;
        lastTapTime = now;

        state.beadCount++;
        state.totalLifetimeCount++;
        updateDailyStats();

        rotateMala();
        // Removed: spawnMantraInSlot() - deity name now static in center
        // Removed: navigator.vibrate(8) - vibration only at 108

        if (state.beadCount >= TOTAL_BEADS) {
            completeMala();
        }

        updateDisplay();
        updateLevelBadge();
        saveState();
    }

    function spawnMantraInSlot() {
        if (availableSlots.length === 0) freeOldestSlot();

        const slotId = availableSlots.pop();
        const position = getSlotPosition(slotId);

        const deity = DEITIES[state.currentDeity];
        const text = state.language === 'hi' ? deity.text_hi : deity.text_en;

        const el = document.createElement('div');
        el.className = 'floating-mantra';
        el.textContent = text;
        el.style.left = position.left;
        el.style.top = position.top;

        canvas.appendChild(el);

        const timeoutId = setTimeout(() => freeSlot(slotId, el), 3500);
        occupiedSlots[slotId] = { element: el, timeoutId };
    }

    function freeSlot(slotId, element) {
        if (element?.parentNode) element.remove();
        delete occupiedSlots[slotId];
        availableSlots.push(slotId);
    }

    function freeOldestSlot() {
        const slotIds = Object.keys(occupiedSlots);
        if (slotIds.length > 0) {
            const oldestId = parseInt(slotIds[0]);
            const slot = occupiedSlots[oldestId];
            clearTimeout(slot.timeoutId);
            if (slot.element) {
                slot.element.style.opacity = '0';
                setTimeout(() => slot.element?.remove(), 150);
            }
            delete occupiedSlots[oldestId];
            availableSlots.push(oldestId);
        }
    }

    // === Mala Functions ===
    function createMalaBeads() {
        malaContainer.innerHTML = '';
        const radius = 270;
        const centerX = 300;
        const centerY = 300;
        const totalBeadsInCircle = BEAD_COUNT + 1; // 54 regular + 1 meru = 55
        const beadOffset = 15; // Half of bead width (30px)

        // Create all beads including Meru at position 0
        for (let i = 0; i < totalBeadsInCircle; i++) {
            const bead = document.createElement('div');

            // Meru bead at position 0 (first bead)
            if (i === 0) {
                bead.className = 'bead meru-bead';
            } else {
                bead.className = 'bead';
            }

            const angleDeg = (i * (360 / totalBeadsInCircle)) - 90;
            const angleRad = angleDeg * (Math.PI / 180);
            bead.style.left = `${centerX + radius * Math.cos(angleRad) - beadOffset}px`;
            bead.style.top = `${centerY + radius * Math.sin(angleRad) - beadOffset}px`;
            malaContainer.appendChild(bead);
        }
    }

    function rotateMala() {
        malaRotation += (360 / TOTAL_BEADS);
        malaContainer.style.transform = `translateX(-50%) rotate(${malaRotation}deg)`;
        malaContainer.querySelectorAll('.bead').forEach(b => b.classList.remove('complete-bead'));
    }

    function completeMala() {
        state.beadCount = 0;
        state.malaCount++;

        if (!state.isMuted && sounds[state.soundType]) {
            sounds[state.soundType].currentTime = 0;
            sounds[state.soundType].play().catch(() => { });
        }

        if (navigator.vibrate) navigator.vibrate([100, 50, 100, 50, 200]);

        const beads = malaContainer.querySelectorAll('.bead');
        if (beads[0]) {
            beads[0].classList.add('complete-bead');
            setTimeout(() => beads[0].classList.remove('complete-bead'), 1000);
        }

        divineFlash.classList.add('active');
        setTimeout(() => divineFlash.classList.remove('active'), 1000);

        completeCount.textContent = `(${state.malaCount})`;
        malaComplete.classList.add('active');
        setTimeout(() => malaComplete.classList.remove('active'), 2000);

        malaCountEl.classList.add('pulse');
        setTimeout(() => malaCountEl.classList.remove('pulse'), 400);

        clearAllMantras();
    }

    function clearAllMantras() {
        Object.keys(occupiedSlots).forEach(slotId => {
            clearTimeout(occupiedSlots[slotId].timeoutId);
            if (occupiedSlots[slotId].element) occupiedSlots[slotId].element.style.opacity = '0';
        });
        setTimeout(() => {
            Object.values(occupiedSlots).forEach(s => s.element?.remove());
            occupiedSlots = {};
            initGridSlots();
        }, 200);
    }

    // === Settings ===
    function setLanguage(lang) {
        state.language = lang;
        updateUI();
        updateSelectedName();
        saveState();
    }

    function setSound(muted) {
        state.isMuted = muted;
        updateUI();
        saveState();
    }

    function applyTheme(deity) {
        document.body.dataset.theme = deity;
    }

    function updateUI() {
        langHi.classList.toggle('active', state.language === 'hi');
        langEn.classList.toggle('active', state.language === 'en');
        soundOnBtn.classList.toggle('active', !state.isMuted);
        soundOffBtn.classList.toggle('active', state.isMuted);
        updateSoundUI();

        // Update name options
        nameOptions.forEach(opt => {
            const deity = opt.dataset.deity;
            const d = DEITIES[deity];
            opt.querySelector('.name-text').textContent = state.language === 'hi' ? d.text_hi : d.text_en;
            opt.classList.toggle('active', deity === state.currentDeity);
        });
    }

    function updateSoundUI() {
        soundOptions.forEach(opt => opt.classList.toggle('active', opt.dataset.sound === state.soundType));
    }

    function updateSelectedName() {
        const deity = DEITIES[state.currentDeity];
        const text = state.language === 'hi' ? deity.text_hi : deity.text_en;
        selectedNameEl.textContent = text;

        // Also update the centered deity name display
        if (deityNameText) {
            deityNameText.textContent = text;
        }
    }

    function resetAllData() {
        if (confirm('Are you sure? This will delete all your Japa history.')) {
            localStorage.removeItem('naamjapa_premium');
            location.reload();
        }
    }

    // === Display ===
    function updateDisplay() {
        beadCountEl.textContent = state.beadCount;
        malaCountEl.textContent = state.malaCount;
        updateSelectedName();
    }

    function updateLevelBadge() {
        let currentLevel = LEVELS[0];
        for (const level of LEVELS) {
            if (state.totalLifetimeCount >= level.min) currentLevel = level;
        }
        levelText.textContent = currentLevel.name;
        // Note: Lucide icons are SVG, no need to update textContent
    }

    function updateDailyStats() {
        const today = new Date().toISOString().split('T')[0];
        if (!state.dailyStats[today]) state.dailyStats[today] = 0;
        state.dailyStats[today]++;
        state.lastActiveDate = today;
    }

    function checkStreak() {
        const today = new Date();
        const todayStr = today.toISOString().split('T')[0];
        if (state.lastActiveDate === todayStr) return;

        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday.toISOString().split('T')[0];

        if (state.lastActiveDate === yesterdayStr && state.dailyStats[yesterdayStr] > 0) {
            state.currentStreak++;
        } else if (state.lastActiveDate !== todayStr) {
            state.currentStreak = 0;
        }
    }

    // === Stats ===
    function updateStats() {
        // Total Naams
        totalNaamsEl.textContent = state.totalLifetimeCount.toLocaleString();

        // Total Malas (108 per mala)
        const totalMalas = Math.floor(state.totalLifetimeCount / 108);
        totalMalasEl.textContent = totalMalas.toLocaleString();

        // Best Day - find max from daily stats
        const dailyCounts = Object.values(state.dailyStats);
        const bestDay = dailyCounts.length > 0 ? Math.max(...dailyCounts) : 0;
        bestDayEl.textContent = bestDay.toLocaleString();

        // Day Streak
        streakCountEl.textContent = state.currentStreak;
    }

    function renderChart() {
        chartContainer.innerHTML = '';
        const days = getLast7Days();
        const maxCount = Math.max(...days.map(d => d.count), 1);

        days.forEach(day => {
            const bar = document.createElement('div');
            bar.className = 'chart-bar';
            const height = Math.max((day.count / maxCount) * 50, 3);
            bar.innerHTML = `
                <span class="bar-value">${day.count}</span>
                <div class="bar" style="height: ${height}px;"></div>
                <span class="bar-label">${day.label}</span>
            `;
            chartContainer.appendChild(bar);
        });
    }

    function getLast7Days() {
        const result = [];
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const dateStr = date.toISOString().split('T')[0];
            result.push({
                date: dateStr,
                label: i === 0 ? 'Today' : dayNames[date.getDay()],
                count: state.dailyStats[dateStr] || 0
            });
        }
        return result;
    }

    // === Persistence ===
    function loadState() {
        const stored = localStorage.getItem('naamjapa_premium');
        if (stored) state = { ...state, ...JSON.parse(stored) };
    }

    function saveState() {
        localStorage.setItem('naamjapa_premium', JSON.stringify(state));
    }

    // === Reminder System ===
    function initReminder() {
        // Restore UI from state
        if (state.reminderEnabled) {
            reminderToggleBtn.classList.add('active');
            reminderTimeSection.classList.add('visible');
        }
        reminderTimeInput.value = state.reminderTime;
        updateReminderStatus();

        // Start checking for reminder time
        if (state.reminderEnabled) {
            startReminderCheck();
        }
    }

    function toggleReminder() {
        if (!state.reminderEnabled) {
            // Enabling - request notification permission first
            requestNotificationPermission().then(granted => {
                if (granted) {
                    state.reminderEnabled = true;
                    reminderToggleBtn.classList.add('active');
                    reminderTimeSection.classList.add('visible');
                    updateReminderStatus();
                    startReminderCheck();
                    saveState();
                } else {
                    reminderStatus.textContent = '❌ Notification permission denied';
                }
            });
        } else {
            // Disabling
            state.reminderEnabled = false;
            reminderToggleBtn.classList.remove('active');
            reminderTimeSection.classList.remove('visible');
            updateReminderStatus();
            saveState();
        }
    }

    function updateReminderTime() {
        state.reminderTime = reminderTimeInput.value;
        updateReminderStatus();
        saveState();
    }

    function updateReminderStatus() {
        if (state.reminderEnabled) {
            const [hours, mins] = state.reminderTime.split(':');
            const period = hours >= 12 ? 'PM' : 'AM';
            const displayHours = hours % 12 || 12;
            reminderStatus.textContent = `⏰ Reminder set for ${displayHours}:${mins} ${period} daily`;
        } else {
            reminderStatus.textContent = '';
        }
    }

    async function requestNotificationPermission() {
        if (!('Notification' in window)) {
            reminderStatus.textContent = '❌ Notifications not supported';
            return false;
        }

        // Request notification permission
        let permission = Notification.permission;
        if (permission !== 'granted' && permission !== 'denied') {
            permission = await Notification.requestPermission();
        }

        if (permission !== 'granted') {
            reminderStatus.textContent = '❌ Notification permission denied';
            return false;
        }

        // Initialize Firebase and get FCM token
        try {
            // Firebase config
            const firebaseConfig = {
                apiKey: "AIzaSyCbpJn70aedORd6dycc88jxSqM178U91ig",
                authDomain: "sanatan-os-push.firebaseapp.com",
                projectId: "sanatan-os-push",
                storageBucket: "sanatan-os-push.firebasestorage.app",
                messagingSenderId: "840881978014",
                appId: "1:840881978014:web:a3d8d5d30f274ecc719ae7b"
            };

            // Initialize Firebase (if not already)
            if (!firebase.apps.length) {
                firebase.initializeApp(firebaseConfig);
            }

            // Register Firebase messaging service worker
            const registration = await navigator.serviceWorker.register('/firebase-messaging-sw.js');
            console.log('Firebase SW registered:', registration);

            // Get messaging instance
            const messaging = firebase.messaging();

            // Get FCM token
            const fcmToken = await messaging.getToken({
                vapidKey: 'BJMOkIPRrC2PEwqO__cjoBT1zObmuzOXuJLPyAK1DjqFSHvMAE1RTf3vjMNpJ6zetEjfcxST0O3IxxjJTkTzYo0',
                serviceWorkerRegistration: registration
            });

            if (fcmToken) {
                console.log('FCM Token:', fcmToken);
                // Save token to state for later use
                state.fcmToken = fcmToken;
                saveState();

                reminderStatus.textContent = '✅ Push notifications enabled!';

                // Listen for foreground messages
                messaging.onMessage((payload) => {
                    console.log('Foreground message received:', payload);
                    // Show notification manually for foreground
                    if (Notification.permission === 'granted') {
                        new Notification(payload.notification?.title || '🙏 Naam Jap', {
                            body: payload.notification?.body || 'Time for Japa!',
                            icon: '/icons/icon-192.png'
                        });
                    }
                });

                return true;
            } else {
                reminderStatus.textContent = '⚠️ Could not get push token';
                return true; // Still allow local notifications
            }
        } catch (err) {
            console.error('Firebase messaging setup failed:', err);
            reminderStatus.textContent = '⚠️ Push setup failed, using local notifications';
            return true; // Fall back to local notifications
        }
    }

    let reminderInterval = null;
    let lastNotifiedDate = null;

    function startReminderCheck() {
        // Check every minute
        if (reminderInterval) clearInterval(reminderInterval);
        reminderInterval = setInterval(checkReminderTime, 60000);
        // Also check immediately
        checkReminderTime();
    }

    function checkReminderTime() {
        if (!state.reminderEnabled) return;

        const now = new Date();
        const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        const today = now.toISOString().split('T')[0];

        // Only notify once per day at the set time
        if (currentTime === state.reminderTime && lastNotifiedDate !== today) {
            lastNotifiedDate = today;
            showReminderNotification();
        }
    }

    function showReminderNotification() {
        if (Notification.permission === 'granted') {
            const notification = new Notification('🙏 Naam Jap Reminder', {
                body: 'Time for your daily Naam Jap sadhana!',
                icon: '../../icons/icon-192.png',
                badge: '../../icons/icon-192.png',
                vibrate: [200, 100, 200],
                tag: 'naamjap-reminder',
                requireInteraction: true
            });

            notification.onclick = () => {
                window.focus();
                notification.close();
            };
        }
    }
    // === SANGHA: Silent Solidarity ===
    // Shows live count of users currently chanting
    function initSangha() {
        try {
            const sanghaCountEl = document.getElementById('sangha-count');
            const sanghaBar = document.getElementById('sangha-bar');

            if (!sanghaCountEl || !sanghaBar) {
                console.log('[Sangha] UI elements not found, skipping');
                return;
            }

            // Firebase config (same as messaging)
            const firebaseConfig = {
                apiKey: "AIzaSyCbpJn70aedORd6dycc88jxSqM178U91ig",
                authDomain: "sanatan-os-push.firebaseapp.com",
                projectId: "sanatan-os-push",
                storageBucket: "sanatan-os-push.firebasestorage.app",
                messagingSenderId: "840881978014",
                appId: "1:840881978014:web:a3d8d5d30f274ecc719ae7b",
                databaseURL: "https://sanatan-os-push-default-rtdb.firebaseio.com"
            };

            // Initialize Firebase if not already done
            if (!firebase.apps.length) {
                firebase.initializeApp(firebaseConfig);
            }

            const database = firebase.database();
            const presenceRef = database.ref('sangha/japa/online');
            const myPresenceRef = presenceRef.push();

            // Track connection state
            const connectedRef = database.ref('.info/connected');
            connectedRef.on('value', (snap) => {
                if (snap.val() === true) {
                    // I'm connected - add myself
                    myPresenceRef.set(true).catch(err => {
                        console.warn('[Sangha] Write failed:', err.message);
                    });

                    // Remove me when I disconnect
                    myPresenceRef.onDisconnect().remove();

                    console.log('[Sangha] Connected to presence system');
                }
            }, (error) => {
                console.warn('[Sangha] Connection error:', error.message);
                sanghaBar.style.display = 'none';
            });

            // Listen for changes in online count
            presenceRef.on('value', (snapshot) => {
                const count = snapshot.numChildren();
                sanghaCountEl.textContent = count;

                // Glow effect based on count
                if (count > 10) {
                    sanghaBar.classList.add('glow-strong');
                    sanghaBar.classList.remove('glow-medium');
                } else if (count > 5) {
                    sanghaBar.classList.add('glow-medium');
                    sanghaBar.classList.remove('glow-strong');
                } else {
                    sanghaBar.classList.remove('glow-medium', 'glow-strong');
                }

                console.log(`[Sangha] ${count} souls chanting`);
            }, (error) => {
                console.warn('[Sangha] Read error:', error.message);
                sanghaBar.style.display = 'none';
            });

        } catch (err) {
            console.error('[Sangha] Init failed:', err.message);
            // Hide the sangha bar if there's an error
            const sanghaBar = document.getElementById('sangha-bar');
            if (sanghaBar) sanghaBar.style.display = 'none';
        }
    }

    // Initialize Sangha after a short delay to not block main UI
    // TEMPORARILY DISABLED - Firebase Realtime Database needs to be created first
    // setTimeout(initSangha, 1500);
    console.log('[Sangha] Disabled - Firebase Realtime Database not configured');
});
